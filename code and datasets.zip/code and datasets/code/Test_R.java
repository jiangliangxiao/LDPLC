/* Experiments on the real-world dataset
 * */
package ceka.LDPLC;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

import ceka.converters.FileLoader;
import ceka.core.Example;
import ceka.core.Label;
import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Worker;
import ceka.utils.PerformanceStatistic;
import ceka.consensus.MajorityVote;
import ceka.consensus.ds.DawidSkene;
import ceka.consensus.gtic.GTIC;
import myqpmatlab.MyQP;
import ceka.MNLDP.*;
import ceka.IWMV.IWMV;
import ceka.DEWSMV.*;
import ceka.WSLC.wslc;

public class Test_R {
	
	private static String dataSetArffDir = "./test/ceka/LDPLC/datasets/real-world/";
	
	private static String[] dataSetArddFix = {"labelme","ruters","leaves"};

	private static String runDir = "./test/ceka/LDPLC/result/results_R/";
	
	private static int times = 1;
		
	public static void main(String[] args) throws Exception {
		for(int i=0;i<dataSetArddFix.length;i++) {
			System.out.print(dataSetArddFix[i]+"\n");
		}
		
		File testDir = new File(runDir);
		if (!testDir.exists())
			testDir.mkdirs();

		// write the result to a file
		FileOutputStream f_i = new FileOutputStream(new File(runDir + "result_Intergration_accuracy.txt"));
		PrintStream result_i = new PrintStream(f_i);

		result_i.format("%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s  %-10s	%-10s	%-10s	%-10s	%-10s	%-10s", 
				"dataset","WSLC","LDPLC","WSLC","LDPLC","WSLC","LDPLC","WSLC","LDPLC","WSLC","LDPLC","WSLC","LDPLC","WSLC","LDPLC");
		result_i.println();
		
		for (int index = 2; index < dataSetArddFix.length; index++) {
			// Download dataset
			Dataset dataset1;
			Dataset dataset2;
			if(index<2) {
				String arffxPath = dataSetArffDir + dataSetArddFix[index]+"\\"+dataSetArddFix[index] + ".arff";
				String responsePath=dataSetArffDir + dataSetArddFix[index]+"\\"+dataSetArddFix[index] + ".response.txt";
				String goldPath=dataSetArffDir + dataSetArddFix[index]+"\\"+dataSetArddFix[index] + ".gold.txt";	
				dataset1 = FileLoader.loadFile(responsePath, goldPath, arffxPath);
				dataset2 = FileLoader.loadFile(responsePath, goldPath, arffxPath);
			}
			else {
				String arffxPath = dataSetArffDir + dataSetArddFix[index]+"\\"+dataSetArddFix[index] + ".arffx";
				String responsePath=dataSetArffDir + dataSetArddFix[index]+"\\"+dataSetArddFix[index] + ".response.txt";
				String goldPath=dataSetArffDir + dataSetArddFix[index]+"\\"+dataSetArddFix[index] + ".gold.txt";	
				dataset1 = FileLoader.loadFileX(responsePath, goldPath, arffxPath);
				dataset2 = FileLoader.loadFileX(responsePath, goldPath, arffxPath);
			}
			
			// WSLC completes dataset1
			wslc wslcA = new wslc();
			dataset1 = wslcA.doInference(dataset1);
			
			// LDPLC completes dataset2
			LDPLC ldplcA = new LDPLC();
			ldplcA.SetIter(5);
			MyQP t1 = new MyQP();
			ldplcA.SetQP(t1);
			ldplcA.doInference(dataset2);
			t1.dispose();
			
			System.out.println(dataSetArddFix[index]);
			
			double IntergrationAcc_mv = 0.0;
			double IntergrationAcc_mv_LC = 0.0;
			double IntergrationAcc_ds = 0.0;
			double IntergrationAcc_ds_LC = 0.0;
			double IntergrationAcc_iwmv = 0.0;
			double IntergrationAcc_iwmv_LC = 0.0;
			double IntergrationAcc_gtic = 0.0;
			double IntergrationAcc_gtic_LC = 0.0;
			double IntergrationAcc_dewsmv = 0.0;
			double IntergrationAcc_dewsmv_LC = 0.0;
			double IntergrationAcc_mnldp = 0.0;
			double IntergrationAcc_mnldp_LC = 0.0;
					
			for (int counts = 0; counts < times; counts++) {
				// MV
				Dataset datasetMV = copyDataset(dataset1);
				MajorityVote mv1 = new MajorityVote();
				mv1.doInference(datasetMV);
				PerformanceStatistic reporter = new PerformanceStatistic();
				reporter.stat(datasetMV);
				IntergrationAcc_mv += reporter.getAccuracy() * 100;
				
				Dataset datasetMV_LC = copyDataset(dataset2);
				MajorityVote mv3 = new MajorityVote();
				mv3.doInference(datasetMV_LC);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMV_LC);
				IntergrationAcc_mv_LC += reporter.getAccuracy() * 100;
				
				// DS
				Dataset datasetDS = copyDataset(dataset1);
				DawidSkene dS = new DawidSkene(20);
				dS.doInference(datasetDS);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDS);
				IntergrationAcc_ds += reporter.getAccuracy() * 100;
				
				Dataset datasetDS_LC = copyDataset(dataset2);
				DawidSkene dS2 = new DawidSkene(20);
				dS2.doInference(datasetDS_LC);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDS_LC);
				IntergrationAcc_ds_LC += reporter.getAccuracy() * 100;
				
                //IWMV
                Dataset datasetIWMV = copyDataset(dataset1);
                IWMV iwmv = new IWMV();
                iwmv.doInference(datasetIWMV);
                reporter = new PerformanceStatistic();
				reporter.stat(datasetIWMV);
                IntergrationAcc_iwmv += reporter.getAccuracy() * 100;
                
                Dataset datasetIWMV_LC = copyDataset(dataset2);
                IWMV iwmv2 = new IWMV();
                iwmv2.doInference(datasetIWMV_LC);
                reporter = new PerformanceStatistic();
				reporter.stat(datasetIWMV_LC);
                IntergrationAcc_iwmv_LC += reporter.getAccuracy() * 100;
				
				// GTIC
                Dataset datasetGTIC = copyDataset(dataset1);
                GTIC gtic1 = new GTIC("./test/ceka/LDPLC/run/run1/");
                gtic1.doInference(datasetGTIC);
                reporter = new PerformanceStatistic();
				reporter.stat(datasetGTIC);
                IntergrationAcc_gtic += reporter.getAccuracy() * 100;
                
                Dataset datasetGTIC_LC = copyDataset(dataset2);
                GTIC gtic3 = new GTIC("./test/ceka/LDPLC/run/run2/");
                gtic3.doInference(datasetGTIC_LC);
                reporter = new PerformanceStatistic();
				reporter.stat(datasetGTIC_LC);
                IntergrationAcc_gtic_LC += reporter.getAccuracy() * 100;
                
                // DEWEntropy
				Dataset datasetdewsmv = copyDataset(dataset1);
				OptimizedError de_entropy = new OptimizedError();
				de_entropy.DE_search(datasetdewsmv);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetdewsmv);
                IntergrationAcc_dewsmv += reporter.getAccuracy() * 100;
                
				Dataset datasetdewsmv_LC = copyDataset(dataset2);
				OptimizedEntropy de_entropy_LC = new OptimizedEntropy();
				de_entropy_LC.DE_search(datasetdewsmv_LC);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetdewsmv_LC);
                IntergrationAcc_dewsmv_LC += reporter.getAccuracy() * 100;
                
                // MNLDP
				Dataset datasetMNLDP = copyDataset(dataset1);
				MNLDP mnldp = new MNLDP();
				MyQP t4 = new MyQP();
				mnldp.setMyQP(t4);
				mnldp.doInference(datasetMNLDP);
				t4.dispose();
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMNLDP);
				IntergrationAcc_mnldp += reporter.getAccuracy() * 100;
				
				Dataset datasetMNLDP_LC = copyDataset(dataset2);
				MNLDP mnldp3 = new MNLDP();
				MyQP t6 = new MyQP();
				mnldp3.setMyQP(t6);
				mnldp3.doInference(datasetMNLDP_LC);
				t6.dispose();
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMNLDP_LC);
				IntergrationAcc_mnldp_LC += reporter.getAccuracy() * 100;
				
				
			}
			result_i.format("%-25s	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f", 
					dataSetArddFix[index],IntergrationAcc_mv / times,IntergrationAcc_mv_LC / times,
					IntergrationAcc_ds / times,IntergrationAcc_ds_LC / times,
					IntergrationAcc_iwmv / times,IntergrationAcc_iwmv_LC / times,
					IntergrationAcc_gtic / times,IntergrationAcc_gtic_LC / times,
					IntergrationAcc_dewsmv / times,IntergrationAcc_dewsmv_LC / times,
					IntergrationAcc_mnldp / times,IntergrationAcc_mnldp_LC / times);
			result_i.println();
		}
	}
	
	// Copy dataset
    public static Dataset copyDataset(Dataset dataset) {
		Dataset newdataset = dataset.generateEmpty();
		int numCateSize = dataset.getCategorySize();
		for (int i = 0; i < numCateSize; i++) {
			Category cate = dataset.getCategory(i);
			newdataset.addCategory(cate.copy());
		}
		for (int j = 0; j < dataset.getExampleSize(); j++) {
			Example example = dataset.getExampleByIndex(j);
			newdataset.addExample(example);
		}
		for (int i = 0; i < dataset.getWorkerSize(); i++) {
			Worker worker = new Worker(dataset.getWorkerByIndex(i).getId());
			for(int l=0;l<dataset.getWorkerByIndex(i).getMultipleNoisyLabelSet(0).getLabelSetSize();l++) {
				Label label = dataset.getWorkerByIndex(i).getMultipleNoisyLabelSet(0).getLabel(l);
				worker.addNoisyLabel(label);
			}
			newdataset.addWorker(worker);
		}
		return newdataset;
    }
}
