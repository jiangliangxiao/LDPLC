package ceka.LDPLC;

import com.mathworks.toolbox.javabuilder.MWException;
import com.mathworks.toolbox.javabuilder.MWNumericArray;

import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;
import ceka.core.Worker;
import weka.core.Utils;
import weka.core.DistanceFunction;
import weka.core.EuclideanDistance;

import myqpmatlab.MyQP;

public class LDPLC{
	public int m_numExamples; // the number of examples
	public int m_numWorkers; // the number of workers
	public int m_numClasses; // the number of classes
	public int m_K = 5; // the number of neighbors
	public int iter = 5; // the number of iterations
	public MyQP m_qp; // optimizer
	protected DistanceFunction m_DistanceFunction = new EuclideanDistance(); // Distance function
	
	public void SetIter(int i) {
		iter = i;
	}
	public void SetK(int k) {
		m_K = k;
	}
	public void SetQP(MyQP qp) {
		m_qp = qp;
	}

	public Dataset doInference(Dataset dataset) throws Exception {
		m_DistanceFunction.setInstances(dataset);
		//sQPtest = new QPtest();
		double[][] Aeq = new double[1][m_K];
		double[] beq = new double[1];
		double[] lb = new double[m_K];
		double[] ub = new double[m_K];
		double[] f = new double[m_K];
		double[][] A = new double[1][m_K];
		double[] b = new double[1];
		beq[0]  = 1;
		for(int i = 0;i < m_K;i++) {
			Aeq[0][i] = 1;
			lb[i] = 0;
			ub[i] = 1;
			f[i] = 0;
			A[0][i] = 0;
		}
		m_numExamples = dataset.getExampleSize();
		m_numClasses = dataset.getCategorySize();
		m_numWorkers = dataset.getWorkerSize();
		
		double[][][] distributes = new double[m_numExamples][m_numWorkers][m_numClasses];
		int[][] knearest = new int[m_numExamples][m_K];
		double[][] knearest_weight = new double[m_numExamples][m_K];
		
		// Calculate the worker similarity
		Dataset datasetwslc = datasetCopy(dataset);
		WorkerSimilarity WS = new WorkerSimilarity();
		double[][] workersimilarty = WS.doInference(datasetwslc);
		
		// Initialize the label distributions
		for(int i=0;i<dataset.getExampleSize();i++) {
	      	Example example = dataset.getExampleByIndex(i);
	      	for(int r=0;r<m_numWorkers;r++) {
	      		Worker worker = dataset.getWorkerByIndex(r);
	      		if(example.getNoisyLabelByWorkerId(worker.getId())==null) {
	      			double[] distribute = new double[m_numClasses];
	      			for(int k=0;k<m_numWorkers;k++) {
	      				if(example.getNoisyLabelByWorkerId(dataset.getWorkerByIndex(k).getId())==null) continue;
	      				distribute[example.getNoisyLabelByWorkerId(dataset.getWorkerByIndex(k).getId()).getValue()]+=workersimilarty[r][k];
	      			}
	      			if(Utils.mean(distribute)!=0) {
	      				Utils.normalize(distribute);
	      			}
	      			distributes[i][r]=distribute;
	      		}
				else {
					double[] distribute1 = new double[m_numClasses];
					int value = example.getNoisyLabelByWorkerId(dataset.getWorkerByIndex(r).getId()).getValue();
					distribute1[value]++;
					distributes[i][r]=distribute1;
				}
	      	}
		}
		
		if(m_K>0) {
			for(int i=0;i<m_numExamples;i++) {
				// Query neighbors
				knearest[i] = find_knearest(dataset,i);
				double[][] G = new double[m_K][m_K];
				// Optimize the neighbors' weights
				G = calculate_G(dataset, knearest[i],i);
				knearest_weight[i] = solveqp(G, f, A, b, Aeq, beq, lb, ub);
			}
		}
		
		// Propagate
		double[][][] old_distributes = new double[m_numExamples][m_numWorkers][m_numClasses];
		double[][][] new_distributes = new double[m_numExamples][m_numWorkers][m_numClasses];
		for(int i=0;i<m_numExamples;i++) {
			for(int r=0;r<m_numWorkers;r++) {
				for(int c=0;c<m_numClasses;c++) {
					old_distributes[i][r][c] = distributes[i][r][c] ;
					new_distributes[i][r][c] = distributes[i][r][c] ;
				}
			}
		}
		for(int k=0;k<iter;k++) {
			for(int i=0;i<m_numExamples;i++) {
				Example example = dataset.getExampleByIndex(i);
				for(int r=0;r<m_numWorkers;r++) {
					if(example.getNoisyLabelByWorkerId(dataset.getWorkerByIndex(r).getId())==null) {
						for(int c=0;c<m_numClasses;c++) {
							new_distributes[i][r][c]=0.5*distributes[i][r][c];
							for(int j=0;j<m_K;j++) {
								new_distributes[i][r][c]+=0.5*knearest_weight[i][j]*old_distributes[knearest[i][j]][r][c];
							}
						}
					}
				}
			}
			for(int i=0;i<m_numExamples;i++) {
				for(int r=0;r<m_numWorkers;r++) {
					for(int c=0;c<m_numClasses;c++) {
						old_distributes[i][r][c] = new_distributes[i][r][c] ;
					}
				}
			}
		}
		
		// Complete the missing labels
		for(int i=0;i<m_numExamples;i++) {
			Example example = dataset.getExampleByIndex(i);
			for(int r=0;r<m_numWorkers;r++) {
				Worker worker = dataset.getWorkerByIndex(r);
				if(example.getNoisyLabelByWorkerId(worker.getId())==null) {
					double[] final_distributes = new_distributes[i][r];
					Integer value = Utils.maxIndex(final_distributes);
					Label label = new Label(null,value.toString(), example.getId(), worker.getId());
					example.addNoisyLabel(label);
					worker.addNoisyLabel(label);
				}
			}
		}
		return dataset;
	}
	
	// Query neighbors
	private int[] find_knearest(Dataset dataset,int index)  throws Exception{
		int[] index_knearest = new int[m_K];
		Example example1 = dataset.getExampleByIndex(index);
		double[] distance = new double[m_numExamples];
		for(int i=0;i<m_numExamples;i++) {
			if(i==index) distance[i] = Double.MAX_VALUE;
			else {
				Example example2 = dataset.getExampleByIndex(i);
				distance[i] = m_DistanceFunction.distance(example1, example2, Double.POSITIVE_INFINITY, null);
			}
		}
		for(int i=0;i<m_K;i++) {
			index_knearest[i] = Utils.minIndex(distance);
			distance[index_knearest[i]] = Double.MAX_VALUE;
		}
		return index_knearest;
 	}
	
	// Calculate optimization matrix
	private double[][] calculate_G(Dataset dataset,int[] knearest, int index) {
		double[][] G = new double[m_K][m_K];
		Example example = dataset.getExampleByIndex(index);
		int num_attribute = example.numAttributes()-1;
		for(int i=0;i<m_K;i++) {
			for(int j=i;j<m_K;j++) {
				G[i][j]=0;
				G[j][i]=0;
				Example example1=dataset.getExampleByIndex(knearest[i]);
				Example example2=dataset.getExampleByIndex(knearest[j]);
				for(int k=0;k<num_attribute;k++) {
					G[i][j]+=(example.value(k)-example1.value(k))*(example.value(k)-example2.value(k));
				}
				G[j][i]=G[i][j];
			}
		}
		return G;
	}
	
	// Optimize the neighbors' weights
	private double[] solveqp(double[][]Htemp,double[]ftemp,double[][] Atemp,double[] btemp,
			double[][] Aeq,double[] beq,double[] lbtemp,double[] ubtemp) throws MWException {
		
		 Object[] result = m_qp.QP(1, Htemp,ftemp,Atemp,btemp,Aeq,beq,lbtemp,ubtemp);
		 MWNumericArray X = (MWNumericArray) result[0];
		 double[][] t = (double[][]) X.toDoubleArray();
		 double[] finalresult = new double[t.length];
		 for(int i = 0; i < finalresult.length;i++) {
			 finalresult[i] = t[i][0];
		 }
		 return finalresult;
	}
	
	// Copy dataset
	public static Dataset datasetCopy(Dataset dataset) {
		Dataset newdataset = dataset.generateEmpty();
		int numCateSize = dataset.getCategorySize();
		for (int i = 0; i < numCateSize; i++) {
			Category cate = dataset.getCategory(i);
			newdataset.addCategory(cate.copy());
		}
		for (int j = 0; j < dataset.getExampleSize(); j++) {
			Example example = dataset.getExampleByIndex(j);
			newdataset.addExample(example);
		}
		for (int i = 0; i < dataset.getWorkerSize(); i++) {
			Worker worker = new Worker(dataset.getWorkerByIndex(i).getId());
			for(int l=0;l<dataset.getWorkerByIndex(i).getMultipleNoisyLabelSet(0).getLabelSetSize();l++) {
				Label label = dataset.getWorkerByIndex(i).getMultipleNoisyLabelSet(0).getLabel(l);
				worker.addNoisyLabel(label);
			}
			newdataset.addWorker(worker);
		}
		return newdataset;
	}
	
	public static void main(String[] args) throws Exception {

	}
}