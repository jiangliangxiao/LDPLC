package ceka.LDPLC;

import ceka.core.*;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Utils;

public class WorkerSimilarity {
    public static int m_numClasses;
    public static int m_numWorkers;
    public static int m_numAttributes;
    public static int m_numExamples;
    public static int m_numK;
    
    public static Dataset[] subDatasets;
    public static double[][] workersimilarty;

    // Calculate the worker similarity
    public double[][] doInference(Dataset dataset) throws Exception {
        m_numClasses = dataset.numClasses();
        m_numWorkers = dataset.getWorkerSize();
        m_numAttributes = dataset.numAttributes();
        m_numExamples = dataset.getExampleSize();
        m_numK = m_numWorkers;
        
        subDatasets = new Dataset[m_numWorkers];
        for(int w=0;w<m_numWorkers;w++) {
			subDatasets[w] = dataset.generateEmpty();
		}
        for(int i = 0; i < m_numExamples; i++) {
            Example example = dataset.getExampleByIndex(i);
            for(int w=0;w<m_numWorkers;w++) {
            	if(example.getNoisyLabelByWorkerId(dataset.getWorkerByIndex(w).getId())!=null) {
            		subDatasets[w].addExample(example);
            	}
            }
        }

        double[][] attributew = new double[m_numWorkers][m_numAttributes-1];
        for(int w=0;w<m_numWorkers;w++) {
        	attributew[w] = calAttributeW(subDatasets[w],dataset.getWorkerByIndex(w).getId());
        }

        workersimilarty = new double[m_numWorkers][m_numWorkers];
        for (int i = 0; i < m_numWorkers; i++) {
            for (int j = 0; j < m_numWorkers; j++) {
                if (i == j) {
                	workersimilarty[i][j] = 0.0;
                }
                else {
                	workersimilarty[i][j] = calSimilarity(attributew[i], attributew[j]);
                }
            }
        }
        
        return workersimilarty;
    }

    // Calculate worker similarity (cosine similarity)
    public static double calSimilarity(double[] w1, double[] w2) {
        double s = 0;
        double fenzi = 0;
        double fenmu1 = 0;
        double fenmu2 = 0;
        for (int i = 0; i < w1.length; i++) {
            fenzi += w1[i] * w2[i];
            fenmu1 += w1[i] * w1[i];
            fenmu2 += w2[i] * w2[i];
        }
        if(fenzi==0||fenmu1==0||fenmu2==0){
            return 0;
        } else {
            s = fenzi / (Math.sqrt(fenmu1) * Math.sqrt(fenmu2));
            return 0.5 * (1 + s);
        }
    }

    // Calculate the feature vector
    public static double[] calAttributeW(Dataset data, String id) throws Exception {
        Instances instances = new Instances(data);
        instances.setClassIndex(instances.numAttributes()-1);
        Dataset dataset = datasetCopy(data);
        int numDataset = instances.numInstances();
        double[] r = new double[m_numAttributes-1];
        double[] pc = new double[m_numClasses];
        double[][] classy = new double[m_numClasses][numDataset];
        for (int j = 0; j < numDataset; j++) {
            Example example = dataset.getExampleByIndex(j);
            Instance instance = instances.instance(j);
            double Class = example.getNoisyLabelByWorkerId(id).getValue();
            instance.setClassValue(Class);
            pc[(int)Class]++;
            classy[(int)Class][j] = 1;
        }
        Utils.normalize(pc);
        for (int i = 0; i < m_numAttributes-1; i++) {
            int numAtt = instances.attribute(i).numValues();
            double[][] attx = new double[numAtt][numDataset];
            double[] attx2 = new double[numDataset];
            double[][] paic = new double[numAtt][m_numClasses];
            if (instances.attribute(i).isNominal()) {
                for (int j = 0; j < numDataset; j++) {
                    Instance instance = instances.instance(j);
                    paic[(int) instance.value(i)][(int) instance.classValue()]++;
                    attx[(int) instance.value(i)][j]=1;
                }
            } else {
                for (int j = 0; j < numDataset; j++) {
                    attx2[j] = instances.instance(j).value(i);
                }
            }
            if (instances.attribute(i).isNominal()) {
                for (int q = 0; q < m_numClasses; q++) {
                    for (int p = 0; p < numAtt; p++) {
                        paic[p][q] /= numDataset;
                        if (paic[p][q] != 0) {
                            r[i] += paic[p][q] * calAttributeR(attx[p], classy[q]);
                        }
                    }
                }
            } else {
                for (int q = 0; q < m_numClasses; q++) {
                    if(pc[q]!=0) {
                        r[i] += pc[q] * calAttributeR(attx2, classy[q]);
                    }
                }
            }
        }
        return r;
    }

    // Calculate Pearson correlation
    public static double calAttributeR(double[] x, double[] y) throws Exception {
        double r = 0;
        double meanx = Utils.mean(x);
        double meany = Utils.mean(y);
        double fenzi = 0;
        double fenmu1 = 0;
        double fenmu2 = 0;
        for(int i = 0; i < x.length; i++) {
            fenzi += (x[i] - meanx)*(y[i] - meany);
            fenmu1 += Math.pow(x[i] - meanx,2);
            fenmu2 += Math.pow(y[i] - meany,2);
        }
        r = fenzi / (Math.sqrt(fenmu1) * Math.sqrt(fenmu2));
        if(Double.isNaN(r)) {
            r=0;
        }
        return r;
    }
    
    // Copy dataset
	public static Dataset datasetCopy(Dataset dataset) {
		Dataset newdataset = dataset.generateEmpty();
		int numCateSize = dataset.getCategorySize();
		for (int i = 0; i < numCateSize; i++) {
			Category cate = dataset.getCategory(i);
			newdataset.addCategory(cate.copy());
		}
		for (int j = 0; j < dataset.getExampleSize(); j++) {
			Example example = dataset.getExampleByIndex(j);
			newdataset.addExample(example);
		}
		for (int i = 0; i < dataset.getWorkerSize(); i++) {
			Worker worker = new Worker(dataset.getWorkerByIndex(i).getId());
			for(int l=0;l<dataset.getWorkerByIndex(i).getMultipleNoisyLabelSet(0).getLabelSetSize();l++) {
				Label label = dataset.getWorkerByIndex(i).getMultipleNoisyLabelSet(0).getLabel(l);
				worker.addNoisyLabel(label);
			}
			newdataset.addWorker(worker);
		}
		return newdataset;
	}
}
