/* Experiments on the simulated datasets
 * */
package ceka.LDPLC;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;

import ceka.core.Worker;
import ceka.core.Label;
import ceka.core.Example;
import ceka.consensus.MajorityVote;
import ceka.consensus.ds.DawidSkene;
import ceka.consensus.gtic.GTIC;
import ceka.converters.FileLoader;
import ceka.core.Category;
import ceka.core.Dataset;
import ceka.utils.PerformanceStatistic;
import myqpmatlab.MyQP;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;
import ceka.DEWSMV.OptimizedEntropy;
import ceka.DEWSMV.OptimizedError;
import ceka.IWMV.IWMV;
import ceka.MNLDP.MNLDP;
import ceka.WSLC.wslc;

import java.util.Random;

public class Test_S {
	
	private static String dataSetArffDir = "./test/ceka/LDPLC/datasets/simulation/";

	private static String[] dataSetArddFix = new File(dataSetArffDir).list();

	private static String runDir = "./test/ceka/LDPLC/result/results_S/";
	
	private static int times = 10;
	
	private static int MAX_WORKR = 40;
	
	// Simulate the crowd workers
	private static void AddWorker(Dataset dataset1, int num_workers) {
		int num_examples = dataset1.getExampleSize();
		int num_classes = dataset1.numClasses();
		double[] workerP = new double[num_workers];
		double[] workerQ = new double[num_workers];
//		double meanQ = 0.75;
//		double stdDevQ = 0.15;
//		Random random1 = new Random();
		for(int w=0;w<num_workers;w++) {
			while(workerP[w]<=0) {
				workerP[w] = Math.random() * 0.1;
			}
			
			// Uniform distribution
			workerQ[w] = Math.random() * 0.3 + 0.6;
			
			// Gaussian distribution
//		    double rawValue;
//		    do {
//		        rawValue = meanQ + stdDevQ * random1.nextGaussian();
//		    } while (rawValue < 0 || rawValue > 1);
//		    workerQ[w] = rawValue;
		}
		for(int w=0;w<num_workers;w++) {
			Worker worker1 = new Worker(String.valueOf(w));
			dataset1.addWorker(worker1);
		}
		for(int w=0;w<num_workers;w++) {
			int num_label = 0;
			for(int i=0;i<num_examples;i++) {
				if(Math.random()<workerP[w]) {
					num_label++;
					Example example1 = dataset1.getExampleByIndex(i);
					Worker worker1 = dataset1.getWorkerByIndex(w);
					int true_label = example1.getTrueLabel().getValue();
					if(Math.random()>workerQ[w]) {
						int false_label = true_label;
						while(false_label == true_label) {
							Random random = new Random();
							false_label = random.nextInt(num_classes);
						}
						true_label = false_label;
					}
					Label label1 = new Label(null,String.valueOf(true_label),example1.getId(),worker1.getId());
					example1.addNoisyLabel(label1);
					worker1.addNoisyLabel(label1);
				}
			}
			if(num_label==0) w--;
		}
	}
	
	
	public static void main(String[] args) throws Exception {
		File testDir = new File(runDir);
		if (!testDir.exists())
			testDir.mkdirs();
		
		// Write the result to a file
		FileOutputStream f_t = new FileOutputStream(new File(runDir + "result_Intergration_accuracy_Uniform.txt"));
		PrintStream result_t = new PrintStream(f_t);
//		FileOutputStream f_t = new FileOutputStream(new File(runDir + "result_Intergration_accuracy_Gaussian.txt"));
//		PrintStream result_t = new PrintStream(f_t);
		
		result_t.format("%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s", "dataset","WSLC","LDPLC","WSLC","LDPLC","WSLC","LDPLC","WSLC","LDPLC","WSLC","LDPLC","WSLC","LDPLC");
		result_t.println();
		
		double IntergrationAcc_mv_WSLC_sum = 0.0;
		double IntergrationAcc_mv_LDPLC_sum = 0.0;
		double IntergrationAcc_ds_WSLC_sum = 0.0;
		double IntergrationAcc_ds_LDPLC_sum = 0.0;
		double IntergrationAcc_iwmv_WSLC_sum = 0.0;
		double IntergrationAcc_iwmv_LDPLC_sum = 0.0;
		double IntergrationAcc_gtic_WSLC_sum = 0.0;
		double IntergrationAcc_gtic_LDPLC_sum = 0.0;
		double IntergrationAcc_dewsmv_WSLC_sum = 0.0;
		double IntergrationAcc_dewsmv_LDPLC_sum = 0.0;
		double IntergrationAcc_mnldp_WSLC_sum = 0.0;
		double IntergrationAcc_mnldp_LDPLC_sum = 0.0;
		
		for(int index = 0; index < dataSetArddFix.length; index++) {
			
			double IntergrationAcc_mv_WSLC = 0.0;
			double IntergrationAcc_mv_LDPLC = 0.0;
			double IntergrationAcc_ds_WSLC = 0.0;
			double IntergrationAcc_ds_LDPLC = 0.0;
			double IntergrationAcc_iwmv_WSLC = 0.0;
			double IntergrationAcc_iwmv_LDPLC = 0.0;
			double IntergrationAcc_gtic_WSLC = 0.0;
			double IntergrationAcc_gtic_LDPLC = 0.0;
			double IntergrationAcc_dewsmv_WSLC = 0.0;
			double IntergrationAcc_dewsmv_LDPLC = 0.0;
			double IntergrationAcc_mnldp_WSLC = 0.0;
			double IntergrationAcc_mnldp_LDPLC = 0.0;
		
			for (int counts = 0; counts < times; counts++) {
				String datasetArffPath = dataSetArffDir + dataSetArddFix[index];
				Dataset dataset1 = FileLoader.loadFile(datasetArffPath);
				
				System.out.println(dataSetArddFix[index]);
				
				// Replace Missing Values
				ReplaceMissingValues m_Missing = new ReplaceMissingValues();
				m_Missing.setInputFormat(dataset1);
				Instances instances = Filter.useFilter(dataset1, m_Missing);
				dataset1 = instancesToDataset(instances,dataset1);
				
				// Simulate crowd workers
				AddWorker(dataset1,MAX_WORKR);
				Dataset dataset2 = copyDataset(dataset1);
				
				// WSLC complete dataset1
				wslc similarty = new wslc();
				dataset1 = similarty.doInference(dataset1);
				
				// LDPLC complete dataset2
				LDPLC test1 = new LDPLC();
				test1.SetIter(5);
				MyQP t1 = new MyQP();
				test1.SetQP(t1);
				test1.doInference(dataset2);
				t1.dispose();
				
				// MV
				Dataset datasetMV = copyDataset(dataset1);
				MajorityVote mv1 = new MajorityVote();
				mv1.doInference(datasetMV);
				PerformanceStatistic reporter = new PerformanceStatistic();
				reporter.stat(datasetMV);
				IntergrationAcc_mv_WSLC += reporter.getAccuracy() * 100;
				
				Dataset datasetMV_LC = copyDataset(dataset2);
				MajorityVote mv3 = new MajorityVote();
				mv3.doInference(datasetMV_LC);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMV_LC);
				IntergrationAcc_mv_LDPLC += reporter.getAccuracy() * 100;
				
				// DS
				Dataset datasetDS = copyDataset(dataset1);
				DawidSkene dS = new DawidSkene(20);
				dS.doInference(datasetDS);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDS);
				IntergrationAcc_ds_WSLC += reporter.getAccuracy() * 100;
				
				Dataset datasetDS_LC = copyDataset(dataset2);
				DawidSkene dS2 = new DawidSkene(20);
				dS2.doInference(datasetDS_LC);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDS_LC);
				IntergrationAcc_ds_LDPLC += reporter.getAccuracy() * 100;
				
	            //IWMV
	            Dataset datasetIWMV = copyDataset(dataset1);
	            IWMV iwmv = new IWMV();
	            iwmv.doInference(datasetIWMV);
	            reporter = new PerformanceStatistic();
				reporter.stat(datasetIWMV);
	            IntergrationAcc_iwmv_WSLC += reporter.getAccuracy() * 100;
	            
	            Dataset datasetIWMV_LC = copyDataset(dataset2);
	            IWMV iwmv2 = new IWMV();
	            iwmv2.doInference(datasetIWMV_LC);
	            reporter = new PerformanceStatistic();
				reporter.stat(datasetIWMV_LC);
	            IntergrationAcc_iwmv_LDPLC += reporter.getAccuracy() * 100;
				
				// GTIC
	            Dataset datasetGTIC = copyDataset(dataset1);
	            GTIC gtic1 = new GTIC("./test/ceka/LDPLC/run/run1/");
	            gtic1.doInference(datasetGTIC);
	            reporter = new PerformanceStatistic();
				reporter.stat(datasetGTIC);
				IntergrationAcc_gtic_WSLC += reporter.getAccuracy() * 100;
	            
	            Dataset datasetGTIC_LC = copyDataset(dataset2);
	            GTIC gtic3 = new GTIC("./test/ceka/LDPLC/run/run2/");
	            gtic3.doInference(datasetGTIC_LC);
	            reporter = new PerformanceStatistic();
				reporter.stat(datasetGTIC_LC);
				IntergrationAcc_gtic_LDPLC += reporter.getAccuracy() * 100;
	            
	            // DEWEntropy
				Dataset datasetdewsmv = copyDataset(dataset1);
				OptimizedError de_entropy = new OptimizedError();
				de_entropy.DE_search(datasetdewsmv);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetdewsmv);
				IntergrationAcc_dewsmv_WSLC += reporter.getAccuracy() * 100;
	            
				Dataset datasetdewsmv_LC = copyDataset(dataset2);
				OptimizedEntropy de_entropy_LC = new OptimizedEntropy();
				de_entropy_LC.DE_search(datasetdewsmv_LC);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetdewsmv_LC);
				IntergrationAcc_dewsmv_LDPLC += reporter.getAccuracy() * 100;
	            
	            // MNLDP
				Dataset datasetMNLDP = copyDataset(dataset1);
				MNLDP mnldp = new MNLDP();
				MyQP t24 = new MyQP();
				mnldp.setMyQP(t24);
				mnldp.doInference(datasetMNLDP);
				t24.dispose();
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMNLDP);
				IntergrationAcc_mnldp_WSLC += reporter.getAccuracy() * 100;
				
				Dataset datasetMNLDP_LC = copyDataset(dataset2);
				MNLDP mnldp3 = new MNLDP();
				MyQP t3 = new MyQP();
				mnldp3.setMyQP(t3);
				mnldp3.doInference(datasetMNLDP_LC);
				t3.dispose();
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMNLDP_LC);
				IntergrationAcc_mnldp_LDPLC += reporter.getAccuracy() * 100;
			}
			
			result_t.format("%-25s	%-10.2f	%-10.2f %-10.2f	%-10.2f %-10.2f	%-10.2f %-10.2f	%-10.2f %-10.2f	%-10.2f %-10.2f	%-10.2f", 
					dataSetArddFix[index],
					IntergrationAcc_mv_WSLC / times,
					IntergrationAcc_mv_LDPLC / times,
					IntergrationAcc_ds_WSLC / times,
					IntergrationAcc_ds_LDPLC / times,
					IntergrationAcc_iwmv_WSLC / times,
					IntergrationAcc_iwmv_LDPLC / times,
					IntergrationAcc_gtic_WSLC / times, 
					IntergrationAcc_gtic_LDPLC / times,
					IntergrationAcc_dewsmv_WSLC / times,
					IntergrationAcc_dewsmv_LDPLC / times,
					IntergrationAcc_mnldp_WSLC  / times,
					IntergrationAcc_mnldp_LDPLC / times);
			result_t.println();
			
			IntergrationAcc_mv_WSLC_sum += IntergrationAcc_mv_WSLC / times;
			IntergrationAcc_mv_LDPLC_sum += IntergrationAcc_mv_LDPLC / times;
			IntergrationAcc_ds_WSLC_sum += IntergrationAcc_ds_WSLC / times;
			IntergrationAcc_ds_LDPLC_sum += IntergrationAcc_ds_LDPLC / times;
			IntergrationAcc_iwmv_WSLC_sum += IntergrationAcc_iwmv_WSLC / times;
			IntergrationAcc_iwmv_LDPLC_sum += IntergrationAcc_iwmv_LDPLC / times;
			IntergrationAcc_gtic_WSLC_sum += IntergrationAcc_gtic_WSLC / times;
			IntergrationAcc_gtic_LDPLC_sum += IntergrationAcc_gtic_LDPLC / times;
			IntergrationAcc_dewsmv_WSLC_sum += IntergrationAcc_dewsmv_WSLC / times;
			IntergrationAcc_dewsmv_LDPLC_sum += IntergrationAcc_dewsmv_LDPLC / times;
			IntergrationAcc_mnldp_WSLC_sum += IntergrationAcc_mnldp_WSLC  / times;
			IntergrationAcc_mnldp_LDPLC_sum += IntergrationAcc_mnldp_LDPLC / times;
			
		}
		result_t.format("%-25s	%-10.2f	%-10.2f %-10.2f	%-10.2f %-10.2f	%-10.2f %-10.2f	%-10.2f %-10.2f	%-10.2f %-10.2f	%-10.2f", 
				"Average",
				IntergrationAcc_mv_WSLC_sum / dataSetArddFix.length,
				IntergrationAcc_mv_LDPLC_sum / dataSetArddFix.length,
				IntergrationAcc_ds_WSLC_sum / dataSetArddFix.length,
				IntergrationAcc_ds_LDPLC_sum / dataSetArddFix.length,
				IntergrationAcc_iwmv_WSLC_sum / dataSetArddFix.length,
				IntergrationAcc_iwmv_LDPLC_sum / dataSetArddFix.length,
				IntergrationAcc_gtic_WSLC_sum / dataSetArddFix.length,
				IntergrationAcc_gtic_LDPLC_sum / dataSetArddFix.length,
				IntergrationAcc_dewsmv_WSLC_sum / dataSetArddFix.length,
				IntergrationAcc_dewsmv_LDPLC_sum / dataSetArddFix.length,
				IntergrationAcc_mnldp_WSLC_sum / dataSetArddFix.length,
				IntergrationAcc_mnldp_LDPLC_sum / dataSetArddFix.length);
		result_t.close();
	}
	
	public static Dataset instancesToDataset(Instances instances,Dataset dataset1) {
		Dataset dataset = new Dataset(instances,instances.numInstances());
		for(int m = 0;m < dataset1.getCategorySize();m++) {
			Category cate = dataset1.getCategory(m);
			dataset.addCategory(cate.copy());
		}
		for(int i = 0;i < instances.numInstances();i++) {
			Instance instance = instances.instance(i);
			Integer truevalue = (int)instance.classValue();
			Example example = new Example(instance);
			Label truelabel = new Label(null, truevalue.toString(), example.getId(), "creat");
			example.setTrueLabel(truelabel);
			dataset.addExample(example);
			
		}
		return dataset;
	}
	
	// Copy dataset
    public static Dataset copyDataset(Dataset dataset) {
		Dataset newdataset = dataset.generateEmpty();
		int numCateSize = dataset.getCategorySize();
		for (int i = 0; i < numCateSize; i++) {
			Category cate = dataset.getCategory(i);
			newdataset.addCategory(cate.copy());
		}
		for (int j = 0; j < dataset.getExampleSize(); j++) {
			Example example = dataset.getExampleByIndex(j);
			newdataset.addExample(example);
		}
		for (int i = 0; i < dataset.getWorkerSize(); i++) {
			Worker worker = new Worker(dataset.getWorkerByIndex(i).getId());
			for(int l=0;l<dataset.getWorkerByIndex(i).getMultipleNoisyLabelSet(0).getLabelSetSize();l++) {
				Label label = dataset.getWorkerByIndex(i).getMultipleNoisyLabelSet(0).getLabel(l);
				worker.addNoisyLabel(label);
			}
			newdataset.addWorker(worker);
		}
		return newdataset;
    }
}
